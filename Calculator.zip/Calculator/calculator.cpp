#include "calculator.h"
#include "math.h"
#include <iostream>

Calculator::Calculator(QWidget *parent) : QDialog(parent){
    value1 = 0;
    value2 = 0;
    value3 = 0;
    operation = "";
    operation2 = "";
    check = false;

    createButtons();
    createLayout();
    setLayout(layout);
    setMinimumHeight(540);
    setMinimumWidth(300);
    setFocus();
    setWindowTitle("Calculator");
}

void Calculator::createButtons(){
    QChar backspace(0x232B);
    QChar divide(0xF7);
    QChar multiply(0x00D7);
    QChar subtract(0x2212);
    QChar squared(0x00B2);
    QChar squaredN(0x207F);
    QChar squereRoot(0x221A);
    QChar pi(0x03A0);
    QChar plusMinus(0xB1);

    QString square = "x";
    square.append(squared);
    QString squareN = "x";
    squareN.append(squaredN);
    QString ten = "10";
    ten.append(squaredN);

    lineEdit = new QLineEdit;
    lineEdit->setAlignment(Qt::AlignRight);
    lineEdit->setDisabled(true);
    lineEdit->setText("0");

    button1 = new QPushButton(square);
    connect(button1, SIGNAL(clicked()), this, SLOT(buttonSquared()));

    button2 = new QPushButton(squareN);
    connect(button2, SIGNAL(clicked()), this, SLOT(buttonSquaredN()));

    button3 = new QPushButton("sin");
    connect(button3, SIGNAL(clicked()), this, SLOT(buttonSine()));

    button4 = new QPushButton("cos");
    connect(button4, SIGNAL(clicked()), this, SLOT(buttonCosine()));

    button5 = new QPushButton("tan");
    connect(button5, SIGNAL(clicked()), this, SLOT(buttonTangent()));

    button6 = new QPushButton(squereRoot);
    connect(button6, SIGNAL(clicked()), this, SLOT(buttonSquareRoot()));

    button7 = new QPushButton(ten);
    connect(button7, SIGNAL(clicked()), this, SLOT(buttonTen()));

    button8 = new QPushButton("log");
    connect(button8, SIGNAL(clicked()), this, SLOT(buttonLog()));

    button9 = new QPushButton("Exp");
    connect(button9, SIGNAL(clicked()), this, SLOT(buttonExp()));

    button10 = new QPushButton("Mod");
    connect(button10, SIGNAL(clicked()), this, SLOT(buttonMod()));

    button11 = new QPushButton("1/x");
    connect(button11, SIGNAL(clicked()), this, SLOT(buttonRecipricol()));

    button12 = new QPushButton("CE");
    connect(button12, SIGNAL(clicked()), this, SLOT(buttonClearEntry()));

    button13 = new QPushButton("C");
    connect(button13, SIGNAL(clicked()), this, SLOT(buttonClear()));

    button14 = new QPushButton(backspace);
    button14->setShortcut(QKeySequence(Qt::Key_Backspace));
    connect(button14, SIGNAL(clicked()), this, SLOT(buttonDelete()));

    button15 = new QPushButton(divide);
    button15->setShortcut(QKeySequence(Qt::Key_Slash));
    connect(button15, SIGNAL(clicked()), this, SLOT(buttonDivide()));

    button16 = new QPushButton(pi);
    connect(button16, SIGNAL(clicked()), this, SLOT(buttonPi()));

    button17 = new QPushButton("7");
    button17->setShortcut(QKeySequence(Qt::Key_7));
    connect(button17, SIGNAL(clicked()), this, SLOT(buttonSeven()));

    button18 = new QPushButton("8");
    button18->setShortcut(QKeySequence(Qt::Key_8));
    connect(button18, SIGNAL(clicked()), this, SLOT(buttonEight()));

    button19 = new QPushButton("9");
    button19->setShortcut(QKeySequence(Qt::Key_9));
    connect(button19, SIGNAL(clicked()), this, SLOT(buttonNine()));

    button20 = new QPushButton(multiply);
    button20->setShortcut(QKeySequence(Qt::Key_X));
    connect(button20, SIGNAL(clicked()), this, SLOT(buttonMultiply()));

    button21 = new QPushButton("n!");
    connect(button21, SIGNAL(clicked()), this, SLOT(buttonFactorial()));

    button22 = new QPushButton("4");
    button22->setShortcut(QKeySequence(Qt::Key_4));
    connect(button22, SIGNAL(clicked()), this, SLOT(buttonFour()));

    button23 = new QPushButton("5");
    button23->setShortcut(QKeySequence(Qt::Key_5));
    connect(button23, SIGNAL(clicked()), this, SLOT(buttonFive()));

    button24 = new QPushButton("6");
    button24->setShortcut(QKeySequence(Qt::Key_6));
    connect(button24, SIGNAL(clicked()), this, SLOT(buttonSix()));

    button25 = new QPushButton(subtract);
    button25->setShortcut(QKeySequence(Qt::Key_Minus));
    connect(button25, SIGNAL(clicked()), this, SLOT(buttonMinus()));

    button26 = new QPushButton(plusMinus);
    connect(button26, SIGNAL(clicked()), this, SLOT(buttonPlusMinus()));

    button27 = new QPushButton("1");
    button27->setShortcut(QKeySequence(Qt::Key_1));
    connect(button27, SIGNAL(clicked()), this, SLOT(buttonOne()));

    button28 = new QPushButton("2");
    button28->setShortcut(QKeySequence(Qt::Key_2));
    connect(button28, SIGNAL(clicked()), this, SLOT(buttonTwo()));

    button29 = new QPushButton("3");
    button29->setShortcut(QKeySequence(Qt::Key_3));
    connect(button29, SIGNAL(clicked()), this, SLOT(buttonThree()));

    button30 = new QPushButton("+");
    button30->setShortcut(QKeySequence(Qt::Key_Plus));
    connect(button30, SIGNAL(clicked()), this, SLOT(buttonPlus()));

    button31 = new QPushButton("(");
    button31->setShortcut(QKeySequence(Qt::Key_ParenLeft));
    connect(button31, SIGNAL(clicked()), this, SLOT(buttonLeftParentheses()));

    button32 = new QPushButton(")");
    button32->setShortcut(QKeySequence(Qt::Key_ParenRight));
    connect(button32, SIGNAL(clicked()), this, SLOT(buttonRightParentheses()));

    button33 = new QPushButton("0");
    button33->setShortcut(QKeySequence(Qt::Key_0));
    connect(button33, SIGNAL(clicked()), this, SLOT(buttonZero()));

    button34 = new QPushButton(".");
    button34->setShortcut(QKeySequence(Qt::Key_Period));
    connect(button34, SIGNAL(clicked()), this, SLOT(buttonDot()));

    button35 = new QPushButton("=");
    button35->setShortcut(QKeySequence(Qt::Key_Return));
    connect(button35, SIGNAL(clicked()), this, SLOT(confirm()));
}

void Calculator::createLayout(){

    layout = new QGridLayout;
    layout->addWidget(lineEdit,0,0,1,5);
    layout->addWidget(button1,3,0,1,1);
    layout->addWidget(button2,3,1,1,1);
    layout->addWidget(button3,3,2,1,1);
    layout->addWidget(button4,3,3,1,1);
    layout->addWidget(button5,3,4,1,1);
    layout->addWidget(button6,4,0,1,1);
    layout->addWidget(button7,4,1,1,1);
    layout->addWidget(button8,4,2,1,1);
    layout->addWidget(button9,4,3,1,1);
    layout->addWidget(button10,4,4,1,1);
    layout->addWidget(button11,5,0,1,1);
    layout->addWidget(button12,5,1,1,1);
    layout->addWidget(button13,5,2,1,1);
    layout->addWidget(button14,5,3,1,1);
    layout->addWidget(button15,5,4,1,1);
    layout->addWidget(button16,6,0,1,1);
    layout->addWidget(button17,6,1,1,1);
    layout->addWidget(button18,6,2,1,1);
    layout->addWidget(button19,6,3,1,1);
    layout->addWidget(button20,6,4,1,1);
    layout->addWidget(button21,7,0,1,1);
    layout->addWidget(button22,7,1,1,1);
    layout->addWidget(button23,7,2,1,1);
    layout->addWidget(button24,7,3,1,1);
    layout->addWidget(button25,7,4,1,1);
    layout->addWidget(button26,8,0,1,1);
    layout->addWidget(button27,8,1,1,1);
    layout->addWidget(button28,8,2,1,1);
    layout->addWidget(button29,8,3,1,1);
    layout->addWidget(button30,8,4,1,1);
    layout->addWidget(button31,9,0,1,1);
    layout->addWidget(button32,9,1,1,1);
    layout->addWidget(button33,9,2,1,1);
    layout->addWidget(button34,9,3,1,1);
    layout->addWidget(button35,9,4,1,1);
    lineEdit->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button1->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button2->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button3->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button4->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button5->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button6->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button7->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button8->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button9->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button10->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button11->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button12->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button13->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button14->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button15->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button16->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button17->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button18->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button19->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button20->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button21->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button22->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button23->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button24->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button25->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button26->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button27->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button28->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button29->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button30->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button31->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button32->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button33->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button34->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    button35->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
}

void Calculator::buttonZero(){
    if(check == false){
        lineEdit->setText("0");
        check = true;
    }
    if(lineEdit->text() != "0"){
        lineEdit->setText(lineEdit->text().append("0"));
    }
}

void Calculator::buttonOne(){
    if(check == false){
        lineEdit->setText("1");
        check = true;
    }
    else{
        lineEdit->setText(lineEdit->text().append("1"));
    }
}

void Calculator::buttonTwo(){
    if(check == false){
        lineEdit->setText("2");
        check = true;
    }
    else{
        lineEdit->setText(lineEdit->text().append("2"));
    }
}

void Calculator::buttonThree(){
    if(check == false){
        lineEdit->setText("3");
        check = true;
    }
    else{
        lineEdit->setText(lineEdit->text().append("3"));
    }
}

void Calculator::buttonFour(){
    if(check == false){
        lineEdit->setText("4");
        check = true;
    }
    else{
        lineEdit->setText(lineEdit->text().append("4"));
    }
}

void Calculator::buttonFive(){
    if(check == false){
        lineEdit->setText("5");
        check = true;
    }
    else{
        lineEdit->setText(lineEdit->text().append("5"));
    }
}

void Calculator::buttonSix(){
    if(check == false){
        lineEdit->setText("6");
        check = true;
    }
    else{
        lineEdit->setText(lineEdit->text().append("6"));
    }
}

void Calculator::buttonSeven(){
    if(check == false){
        lineEdit->setText("7");
        check = true;
    }
    else{
        lineEdit->setText(lineEdit->text().append("7"));
    }
}

void Calculator::buttonEight(){
    if(check == false){
        lineEdit->setText("8");
        check = true;
    }
    else{
        lineEdit->setText(lineEdit->text().append("8"));
    }
}

void Calculator::buttonNine(){
    if(check == false){
        lineEdit->setText("9");
        check = true;
    }
    else{
        lineEdit->setText(lineEdit->text().append("9"));
    }
}

void Calculator::buttonDot(){
    if(check == true && fmod(lineEdit->text().toFloat(), 1) == 0 ){
        lineEdit->setText(lineEdit->text().append("."));
    } else if(lineEdit->text().toFloat() == 0){
        lineEdit->setText(lineEdit->text().append("."));
        check = true;
    } else if(check == false){
        lineEdit->setText("0.");
        check = true;
    }
}

void Calculator::buttonClear(){
    value1 = 0;
    value2 = 0;
    value3 = 0;
    operation = "";
    operation2 = "";
    check = false;
    lineEdit->setText("0");
}

void Calculator::buttonClearEntry(){
    lineEdit->setText("0");
    check = false;
}

void Calculator::buttonDelete(){
    lineEdit->setText(lineEdit->text().left(lineEdit->text().length() - 1));
    if(lineEdit->text() == NULL){
        lineEdit->setText("0");
        check = false;
    }
}

void Calculator::buttonDivide(){
    if(value1 == 0){
        value1 = lineEdit->text().toDouble();
    } else {
        confirm();
    }
    operation = "divide";
    check = false;
}

void Calculator::buttonFactorial(){
    int number = 1;
    value1 = lineEdit->text().toDouble();
    for(int i=1;i<=value1;i++){
        number *= i;
    }
    value1 = number;
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonLog(){
    value1 = lineEdit->text().toDouble();
    value1 = qLn(value1);
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonExp(){
    value1 = lineEdit->text().toDouble();
    value1 = qExp(value1);
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonMinus(){
    if(value1 == 0){
        value1 = lineEdit->text().toDouble();
    } else {
        confirm();
    }
    operation = "minus";
    check = false;
}

void Calculator::buttonMod(){
    if(value1 == 0){
        value1 = lineEdit->text().toDouble();
    } else {
        confirm();
    }
    operation = "mod";
    check = false;
}

void Calculator::buttonMultiply(){
    if(value1 == 0){
        value1 = lineEdit->text().toDouble();
    } else {
        confirm();
    }
    operation = "multiply";
    check = false;
}

void Calculator::buttonPi(){
    if(check == false){
        lineEdit->setText(QString::number(M_PI));
        check = true;
    }
}

void Calculator::buttonPlus(){
    if(value1 == 0){
        value1 = lineEdit->text().toDouble();
    } else {
        confirm();
    }
    operation = "plus";
    check = false;
}

void Calculator::buttonPlusMinus(){
    value1 = lineEdit->text().toDouble();
    value1 *= -1;
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonRecipricol(){
    value1 = lineEdit->text().toDouble();
    value1 = 1/value1;
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonSquared(){
    value1 = lineEdit->text().toDouble();
    value1 *= value1;
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonSquaredN(){
    if(value1 == 0){
        value1 = lineEdit->text().toDouble();
    } else {
        confirm();
    }
    operation = "squareN";
    check = false;
}

void Calculator::buttonSquareRoot(){
    value1 = lineEdit->text().toDouble();
    value1 = qSqrt(value1);
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonTen(){
    value1 = lineEdit->text().toDouble();
    value1 = qPow(10,value1);
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonSine(){
    value1 = lineEdit->text().toDouble();
    value1 = qSin(value1);
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonCosine(){
    value1 = lineEdit->text().toDouble();
    value1 = qCos(value1);
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonTangent(){
    value1 = lineEdit->text().toDouble();
    value1 = qTan(value1);
    lineEdit->setText(QString::number(value1));
    check = false;
}

void Calculator::buttonLeftParentheses(){
    if(operation != ""){
        operation2 = operation;
        operation = "";
        value3 = value1;
        value1 = 0;
        check = false;
    }
}

void Calculator::buttonRightParentheses(){
    confirm();
    std::cout<<"value 1 = "<<value1;
    std::cout<<"value 2 = "<<value2;
    std::cout<<"value 3 = "<<value3<<" ";
    if(value3 != 0 && operation2 != ""){
        check = true;
        operation = operation2;
        if(operation == "mod" || operation == "divide" || operation == "squareN"){
            float temp;
            temp = value1;
            value1 = value3;
            value3 = temp;
        }
        lineEdit->setText(QString::number(value3));
        value3 = 0;
        operation2 = "";
        confirm();
    }
}

void Calculator::confirm(){
    if(operation == "plus" && check == true){
        value2 = lineEdit->text().toDouble();
        value1 += value2;
        value2 = 0;
    }
    if(operation == "minus" && check == true){
        value2 = lineEdit->text().toDouble();
        value1 -= value2;
        value2 = 0;
    }
    if(operation == "multiply" && check == true){
        value2 = lineEdit->text().toDouble();
        value1 *= value2;
        value2 = 0;
    }
    if(operation == "divide" && check == true){
        value2 = lineEdit->text().toDouble();
        value1 /= value2;
        value2 = 0;
    }
    if(operation == "mod" && check == true){
        value2 = lineEdit->text().toDouble();
        value1 = fmod(value1, value2);
        value2 = 0;
    }
    if(operation == "squareN" && check == true){
        //std::cout<<"value 1 = "<<value1;
        //std::cout<<"value 2 = "<<value2;
        //std::cout<<"value 3 = "<<value3;
        value2 = lineEdit->text().toDouble();
        value1 = qPow(value1, value2);
        value2 = 0;
    }
    lineEdit->setText(QString::number(value1));
    operation = "";
    check = false;
}
