#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>
#include <QTableWidget>
#include <QPushButton>
#include <QGridLayout>
#include <QtMath>

class Calculator : public QDialog{
    Q_OBJECT
public:
    Calculator(QWidget *parent = 0);
private slots:
    void buttonZero();
    void buttonOne();
    void buttonTwo();
    void buttonThree();
    void buttonFour();
    void buttonFive();
    void buttonSix();
    void buttonSeven();
    void buttonEight();
    void buttonNine();
    void buttonDot();
    void buttonClear();
    void buttonClearEntry();
    void buttonDelete();
    void buttonDivide();
    void buttonLog();
    void buttonExp();
    void buttonFactorial();
    void buttonMinus();
    void buttonMod();
    void buttonMultiply();
    void buttonPi();
    void buttonPlus();
    void buttonPlusMinus();
    void buttonRecipricol();
    void buttonSquared();
    void buttonSquaredN();
    void buttonSquareRoot();
    void buttonTen();
    void buttonSine();
    void buttonCosine();
    void buttonTangent();
    void buttonLeftParentheses();
    void buttonRightParentheses();
    void confirm();
private:
    double value1;
    double value2;
    double value3;
    bool check;
    void createButtons();
    void createLayout();
    QGridLayout *layout;
    QLineEdit *lineEdit;
    QPushButton *button1;
    QPushButton *button2;
    QPushButton *button3;
    QPushButton *button4;
    QPushButton *button5;
    QPushButton *button6;
    QPushButton *button7;
    QPushButton *button8;
    QPushButton *button9;
    QPushButton *button10;
    QPushButton *button11;
    QPushButton *button12;
    QPushButton *button13;
    QPushButton *button14;
    QPushButton *button15;
    QPushButton *button16;
    QPushButton *button17;
    QPushButton *button18;
    QPushButton *button19;
    QPushButton *button20;
    QPushButton *button21;
    QPushButton *button22;
    QPushButton *button23;
    QPushButton *button24;
    QPushButton *button25;
    QPushButton *button26;
    QPushButton *button27;
    QPushButton *button28;
    QPushButton *button29;
    QPushButton *button30;
    QPushButton *button31;
    QPushButton *button32;
    QPushButton *button33;
    QPushButton *button34;
    QPushButton *button35;
    QString operation;
    QString operation2;
};


#endif // CALCULATOR_H
